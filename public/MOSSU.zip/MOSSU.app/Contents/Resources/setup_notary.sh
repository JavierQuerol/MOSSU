#!/usr/bin/env bash
set -euo pipefail

echo "--- MOSSU • Configuración de notarización (notarytool) ---"

# Comprobar dependencias
if ! xcrun notarytool --help >/dev/null 2>&1; then
  echo "❌ Xcode Command Line Tools / notarytool no disponibles."
  echo "   Abre Xcode, acepta licencias y asegúrate de tener CLT instaladas."
  exit 1
fi

read -rp "Apple ID (correo Apple Developer): " APPLE_ID
read -rp "Team ID (10 caracteres, p.ej. 4385X6LBF4): " TEAM_ID
read -rsp "App-specific password (no se muestra): " APP_PASSWORD
echo ""
read -rp "Nombre del perfil en llavero [AC_MOSSU]: " PROFILE
PROFILE=${PROFILE:-AC_MOSSU}

echo "\n🔐 Guardando credenciales en el llavero con perfil: $PROFILE"
xcrun notarytool store-credentials "$PROFILE" \
  --apple-id "$APPLE_ID" \
  --team-id "$TEAM_ID" \
  --password "$APP_PASSWORD"

ZSHRC="$HOME/.zshrc"
LINE="export NOTARY_PROFILE=\"$PROFILE\""

echo "\n🔧 Añadiendo NOTARY_PROFILE a $ZSHRC"
touch "$ZSHRC"
if grep -q "^export NOTARY_PROFILE=" "$ZSHRC"; then
  # Reemplazar la línea existente
  if sed --version >/dev/null 2>&1; then
    sed -i "s/^export NOTARY_PROFILE=.*/$LINE/" "$ZSHRC"
  else
    # macOS BSD sed
    sed -i '' "s/^export NOTARY_PROFILE=.*/$LINE/" "$ZSHRC"
  fi
else
  {
    echo ""
    echo "# MOSSU notarization profile"
    echo "$LINE"
  } >> "$ZSHRC"
fi

echo "\n✅ Perfil guardado y NOTARY_PROFILE configurado."
echo "➡ Abre una nueva terminal o ejecuta: source \"$ZSHRC\""
echo "➡ Ahora puedes lanzar ./deploy.sh para firmar y notarizar."

